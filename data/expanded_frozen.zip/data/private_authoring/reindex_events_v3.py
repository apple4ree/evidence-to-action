import json,hashlib,copy,shutil
from pathlib import Path
P=Path('research_2026_11/underspecification_proposal/expanded_natural_language_experiment')
meta=json.loads((P/'data/private_variant_metadata.json').read_text());targets=[x['record_id'] for x in meta['entries'] if 'long_history' in x['complexity_tags']]
dev=json.loads((P/'dev_selection.json').read_text())['record_ids'];assert not set(dev)&set(targets)
old_snapshot=json.loads((P/'data/public_author_snapshot_v2.json').read_text())['sha256']
archive=P/'data/private_archive/event_reindex_v2';archive.mkdir(parents=True,exist_ok=True)
for name in ['private_author_gold.json','private_variant_metadata.json']:
 shutil.copyfile(P/'data'/name,archive/name)
(archive/'public_cases').mkdir(exist_ok=True)
map_by={};newhash={}
for rid in targets:
 q=P/'data/public_cases'/f'{rid}.json';assert hashlib.sha256(q.read_bytes()).hexdigest()==old_snapshot[rid]
 shutil.copyfile(q,archive/'public_cases'/q.name);c=json.loads(q.read_text());before=copy.deepcopy(c)
 mapping={e['event_id']:f'e{i+1}' for i,e in enumerate(c['history'])};assert len(mapping)==len(c['history'])
 for e in c['history']:e['event_id']=mapping[e['event_id']]
 assert [{k:v for k,v in e.items() if k!='event_id'} for e in c['history']]==[{k:v for k,v in e.items() if k!='event_id'} for e in before['history']]
 assert {k:v for k,v in c.items() if k!='history'}=={k:v for k,v in before.items() if k!='history'}
 q.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');newhash[rid]=hashlib.sha256(q.read_bytes()).hexdigest();map_by[rid]=mapping

def remap(obj,mapping):
 if isinstance(obj,list):return [remap(v,mapping) for v in obj]
 if isinstance(obj,dict):return {k:remap(v,mapping) for k,v in obj.items()}
 if isinstance(obj,str):return mapping.get(obj,obj)
 return obj

gold=json.loads((P/'data/private_author_gold.json').read_text())
for rid,mapping in map_by.items():
 gold['entries'][rid]=remap(gold['entries'][rid],mapping)
 current=json.loads((P/'data/public_cases'/f'{rid}.json').read_text());newtexts={x['event_id']:x['content'] for x in current['history']};old=json.loads((archive/'public_cases'/f'{rid}.json').read_text());oldtexts={x['event_id']:x['content'] for x in old['history']}
 for a,b in mapping.items():assert oldtexts[a]==newtexts[b]
 for rel in gold['entries'][rid]['requirement_relations']:assert set(rel['evidence_event_ids'])<=set(newtexts)
(P/'data/private_author_gold.json').write_text(json.dumps(gold,ensure_ascii=False,indent=2)+'\n')
for i,m in enumerate(meta['entries']):
 rid=m['record_id']
 if rid not in map_by:continue
 mapping=map_by[rid];old_changes=copy.deepcopy(m['changed_elements']['events']);baseline=json.loads((P/'data/public_cases'/f'{m["baseline_record_id"]}.json').read_text());bids={e['event_id'] for e in baseline['history']}
 m=remap(m,mapping)
 for j,event in enumerate(m['changed_elements']['events']):
  oldid=old_changes[j]['event_id'];event['baseline_event_id']=oldid if oldid in bids else None;event['current_event_id']=mapping.get(oldid)
 m['maintained_elements']['event_correspondence']=[{'baseline_event_id':oldid,'current_event_id':mapping[oldid]} for oldid in meta['entries'][i]['maintained_elements']['unchanged_event_ids']]
 m['event_id_map_ref']='data/event_id_map_v3.json';m['original_event_id_namespace']='v2'
 c=json.loads((P/'data/public_cases'/f'{rid}.json').read_text());m['serialized_characters']=len(json.dumps(c,ensure_ascii=False));meta['entries'][i]=m
(P/'data/private_variant_metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
blindpath=P/'review/blind_labels.json';blind=json.loads(blindpath.read_text());blind_before_hash=hashlib.sha256(blindpath.read_bytes()).hexdigest()
for i,r in enumerate(blind['records']):
 rid=r['record_id']
 if rid in map_by:
  blind['records'][i]=remap(r,map_by[rid]);blind['records'][i]['public_input_sha256_before_reindex']=r['public_input_sha256'];blind['records'][i]['public_input_sha256']=newhash[rid]
blind['metadata']['reindex_note']='Mechanical event-ID mapping only; original blind labels and semantic judgments unchanged. Original frozen review/blind_labels.json preserved.'
blind['metadata']['source_blind_labels_sha256']=blind_before_hash
(P/'review/blind_labels_reindexed.json').write_text(json.dumps(blind,ensure_ascii=False,indent=2)+'\n')
assert hashlib.sha256(blindpath.read_bytes()).hexdigest()==blind_before_hash
for r in blind['records']:
 if r['record_id'] in targets:
  c=json.loads((P/'data/public_cases'/f'{r["record_id"]}.json').read_text());assert set(r.get('evidence_ids',[]))<={x['event_id'] for x in c['history']}
currenthash={q.stem:hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted((P/'data/public_cases').glob('*.json'))}
assert all(currenthash[r]==old_snapshot[r] for r in currenthash if r not in targets)
assert all(currenthash[r]==old_snapshot[r] for r in dev)
(P/'data/event_id_map_v3.json').write_text(json.dumps({'reason':'Remove core-versus-distractor event-ID namespace cue before test prediction. History content and order unchanged.','old_snapshot':'public_author_snapshot_v2.json','new_snapshot':'public_author_snapshot_v3.json','record_mappings':map_by,'dev_unchanged':dev},indent=2)+'\n')
(P/'data/public_author_snapshot_v3.json').write_text(json.dumps({'status':'Final public author snapshot after event-ID-only reindex; v2 content archived and original blind judgments preserved','sha256':currenthash,'changed_records':targets,'semantic_content_changed':False,'history_order_changed':False},indent=2)+'\n')
print({'reindexed_cases':len(targets),'dev_cases_unchanged':len(dev),'blind_original_hash_preserved':True})

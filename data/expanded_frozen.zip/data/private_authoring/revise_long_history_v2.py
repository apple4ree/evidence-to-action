import json,hashlib
from pathlib import Path
P=Path('research_2026_11/underspecification_proposal/expanded_natural_language_experiment')
D={
'F02':[
'DataCouncil case DC-81: dataset winter-cohort, recipient AcornLab, purpose fraud-audit. External aggregated export approved for the November audit; direct identifiers must remain in the controlled workspace.',
'ExportQueue job X-19 for partner CedarAnalytics: waiting for a destination certificate renewal. The previous job completed with 248 aggregate rows and an empty identifier column.',
'DatasetCatalog revision 14: monthly churn summaries are partitioned by billing region. The data steward changed the refresh cadence from daily to weekly after a downstream reconciliation review.',
'AccessReview AR-56: AcornLab analyst membership renewed. The review concerns access to the collaboration portal; the reviewers recorded two departing staff accounts for removal.',
'PartnerRegistry: CedarAnalytics uses certificate thumbprint 72af. The integration contact requested a delivery window after 18:00 UTC and a retry cap of three attempts.',
'DataCouncil case DC-77: autumn-survey export to AcornLab denied because the questionnaire includes free-text responses. The steward was asked to prepare a redacted aggregate before resubmission.',
'PipelineMetrics: aggregation-worker processed 26 partitions overnight. Two partitions were retried after a storage timeout, and the resulting row counts matched the daily manifest.',
'PrivacyOperations: documentation for pseudonymous account keys was updated in catalog revision 15. Owners must select the applicable export mode when creating a new export job.',
'Incident log EX-12: an August partner export was delayed by a destination firewall rule. The incident closed after network review; operations kept the retry trace for the monthly reliability report.',
'DataCouncil case DC-86: cohort-summer to BirchInstitute for retention-study approved in aggregate form. Its package includes country-level totals and suppresses cohorts smaller than the approved threshold.',
'ExportReceipt X-17: winter-cohort aggregate delivered to AcornLab at 07:40 UTC; receipt signature verified. The archive checksum and compressed-file size were added to the delivery ledger.',
'Workflow note: a data steward reassigned case DC-90 from the metrics team to the customer-insights team. The requester will receive a separate notification when the council records its decision.' ],
'F03':[
'ReleaseQueue entry REL-81: ledger artifact sha256:7b11 deployed to eu-central yesterday. SecurityScan passed and release-manager approval was attached before the rollout started.',
'BuildSystem: billing-worker artifact sha256:ab27 compiled from commit 891e. Unit tests passed; packaging emitted a warning about an optional documentation bundle.',
'StagingRunner: ledger smoke tests checked health probes, read-only query routing and connection recycling. Test duration was four minutes; the test account was removed after cleanup.',
'SecurityScan report SC-710: sha256:ab27 PASS with no blocking findings. The report is signed by the scanner service and retained with the billing-worker release packet.',
'ReleaseManager signed note REL-78: analytics artifact sha256:cc91 approved for us-west. Rollout should begin after the ingestion queue drains and stop if the canary error budget is exceeded.',
'ChangeCalendar: the eu-central database maintenance starts at 23:00 UTC. Release engineering moved two nonurgent frontend updates to the following morning.',
'ArtifactRegistry: sha256:9f0b is an archived ledger build with the feature flag disabled. Its release packet includes scan SC-702 and a canceled staging deployment.',
'CanaryMetrics: the current ledger production version has stable latency. A short connection spike occurred at 08:45 UTC when the load balancer replaced a node.',
'BuildSystem: documentation links for release checklists moved to the engineering portal. Existing signed release packets remain attached to their artifact registry records.',
'IncidentRegistry INC-73: telemetry-worker rollback completed in us-east. The team will investigate an exporter memory regression and file a new release request after the fix.',
'RolloutQueue: inventory-service awaits a requested business window. The queue contains its artifact hash and target region, but the operator has not started the production action.',
'Security operations note: scanner workers restarted after a certificate refresh. Previously issued signed scan reports retain their artifact identifiers and result timestamps.' ],
'F06':[
'CalibrationService certificate C-181: MX-89 expired on 31 October. The workshop scheduled a reference measurement and will issue a new certificate after the technician reviews the readings.',
'ShippingDesk manifest SHP-310: pressure gauge PG-14 packed for RiverSite. Foam inserts and a temperature indicator were added because the route includes an overnight transfer.',
'InstrumentInventory: MX-87 is stored in cabinet B with its accessories. A lending request from the training team was placed on hold until the equipment owner confirms availability.',
'CarrierTracking: consignment C-200 arrived at HillSite at 16:20 UTC. The receiving technician signed for two cases and reported no damage to the outer packaging.',
'CalibrationService certificate C-175: PG-14 passed the current pressure range checks. The signed report lists reference standard RS-9 and the technician assigned to the measurement bench.',
'Workshop log: a replacement battery for MX-90 is on order. The instrument remains on the repair shelf; the service ticket includes a photo of the battery compartment label.',
'HarborSite receiving desk: deliveries are accepted between 09:00 and 17:00. The team asked carriers to call the loading bay before unloading heavy equipment.',
'AssetMovement report: three oscilloscopes returned from FieldOffice. Their transit cases are dry and undamaged; accessory counts will be reconciled during the next inventory check.',
'CalibrationService certificate C-169: MX-86 current through December. The report covers voltage measurements only and excludes its optional temperature probe.',
'PackingStation: label printer PS-2 is back online. Reprinted labels preserve the same shipment identifiers, and the operator reconciled discarded labels with the afternoon manifest.',
'Carrier route planning: RiverSite consignments will transfer at EastHub. The carrier recommends using tamper-evident seals for instruments sent through the shared consolidation facility.',
'Workshop schedule: reference standard RS-10 will be inspected on Thursday. Technicians assigned to that bench will use RS-9 for already scheduled pressure calibration appointments.' ],
'F08':[
'LegalDesk signed decision LD-212: Kestrel-MSA v4 approved. The signed packet includes the liability schedule and the annex that was present when the editor submitted that revision.',
'ContractMetadata: Sparrow-SOW v2 names Sparrow as partner and includes a fixed delivery schedule. The business owner asked for publication after the partner updates its billing contact.',
'Negotiation note: the Kestrel procurement team prefers weekly delivery reports. The account manager recorded that preference for the next service-review meeting.',
'LegalDesk queue LD-219: Finch-DPA v3 assigned to a privacy reviewer. The response due date was extended after the partner supplied a revised subcontractor list.',
'DocumentStore audit: Kestrel-MSA v3 archived with a signed checksum. The archive entry includes the original author and the timestamp of the last legal review on that version.',
'PartnerRegistry: Kestrel changed its postal billing address. The finance team confirmed that the legal entity identifier remains the same and updated the customer master record.',
'Contract publication receipt PUB-18: Raven-MSA v2 sent to Raven through the partner portal. The portal acknowledged the upload and retained the public packet identifier.',
'Negotiation comment: a contributor suggested shortening clause 8 in the Kestrel draft. The editor added the suggestion to the document review thread for later discussion.',
'LegalDesk signed decision LD-215: Sparrow-SOW v1 approved. The newer v2 adds a service milestone and is tracked separately by the publication queue.',
'PortalStatus: partner document uploads are processing normally. A temporary thumbnail-rendering delay affects preview images but not the stored document payloads.',
'DocumentStore revision note: formatting fixes to Finch-DPA were saved as v4. The editor preserved the v3 text and attached a comparison report to the new version.',
'AccountManager diary: Kestrel requested a call to discuss rollout timing. The agenda includes training, support contacts and the date of the first operational review.' ],
'F11':[
'CertifiedRoster for analytics: Arun and Bea are currently certified. The analytics lead renewed its night coverage roster after completing the quarterly training audit.',
'RestRegistry: Tess has a protected rest period for night-4. Scheduling software marked that interval after the daytime maintenance shift was extended yesterday.',
'ShiftExchange request SW-17: Bea offered to exchange a weekend analytics shift with Arun. The service lead has not yet entered a final schedule update.',
'TrainingRegistry: Mira completed search-service incident drills. Certification processing is pending the assessor signature; her existing storage-service certificate remains current.',
'ServiceDirectory: search and analytics have separate on-call rotations. The escalation numbers were tested this morning and both service mailboxes accepted the test messages.',
'RestRegistry: Arun has no rest restriction for night-2. The record includes the end of his preceding shift and the scheduled start of the next assignment.',
'Incident review INC-28: the daytime search operator resolved a cache warm-up issue. The handover note recommends checking query volume during the evening traffic peak.',
'CertifiedRoster archive: search roster from last quarter listed Tess, Arun and Mira. The training coordinator retained the archive for the certification change audit.',
'Scheduling log: night-5 moved to a different holiday coverage pattern. The lead sent the revised shift plan to the operators assigned to that date.',
'EmployeeDirectory: Bea moved to the platform organization last month. Her employee record retains the same contact details and emergency phone number.',
'Rotation dashboard: the next search-service exercise will cover backup restoration. Operators can attend either session; the trainer will record completion after the exercise.',
'RestRegistry: Tess rest audit for the previous week is complete. The scheduler corrected an old duplicate shift entry and notified payroll of the adjustment.' ],
'F13':[
'AssetBoard signed batch B-3: LAB-31 review pending last month. The board minutes requested a valuation before deciding how the retired instrument should be handled.',
'AssetInventory: LAB-33 is still assigned to the materials team. Its owner requested a replacement display, and procurement opened a repair order rather than a disposal request.',
'VendorRegistry: ReclaimWorks has a current electronics-recycling license. Its certificate covers circuit boards and cables but excludes chemical storage containers.',
'PickupManifest PM-48: LAB-32 scheduled for collection at the south loading bay. The warehouse attached a weight estimate and a photograph of the sealed transit case.',
'AssetBoard signed batch B-9: disposal approved for LAB-40 and LAB-41. Both assets were decommissioned after the laboratory replaced their measurement controllers.',
'GreenLoop account note: the recycler changed its invoice contact. Accounts payable updated the vendor profile after confirming the signed contact-change request.',
'WasteInventory: two empty reagent drums are awaiting a separate hazardous-material assessment. Facilities stored them in the marked containment area pending the assessment.',
'AssetBoard archive B-1: LAB-29 disposal request withdrawn. The engineering team found a replacement part and returned the unit to service after testing.',
'VendorRegistry: ScrapNorth license expired in September. The registry entry includes a renewal application but no issued replacement certificate.',
'LoadingBay calendar: a freight collection is scheduled for Friday afternoon. Warehouse staff reserved the forklift and checked that the ramp is clear.',
'AssetInventory: LAB-30 has been transferred to the training room. The transfer record includes its accessories and the name of the receiving equipment custodian.',
'FinanceLedger: the depreciation balance for the retired laboratory fleet was reconciled. Asset disposal proceeds will be posted when vendor settlement statements arrive.' ],
'F16':[
'RefundAuthority archived decision: O-901 limit 20, superseded by the current unused authorizations A and B. The archive keeps the earlier request and customer-service comments.',
'PaymentRecord: O-902 paid using wallet-credit. The customer opened a separate request about a duplicate delivery charge, and the support team is collecting the carrier receipt.',
'RefundAuthority: O-903 unused authorization C=25, standalone. The decision concerns a damaged accessory and includes the inspection photograph submitted by the warehouse.',
'SettlementLedger: refund RF-88 for O-899 settled yesterday. The processor returned a receipt identifier and the accounting job reconciled it with the original payment.',
'Customer message on O-904: please replace the missing item rather than refund it. The support agent forwarded the replacement request to fulfillment.',
'RefundAuthority: O-902 authorization D=30, approved for delivery adjustment. It permits aggregation only with another authorization explicitly naming O-902.',
'CardProcessorStatus: refund posting is delayed by one business day for a small group of issuers. Accepted processor requests retain their original transaction identifiers.',
'OrderMetadata: O-900 contains two products and one optional accessory. The order was delivered to the registered address and closed by the fulfillment team.',
'RefundAuthority: O-905 authorization E=70 already consumed by RF-91. The remaining refundable balance in that authorization is zero.',
'Finance note: the monthly reconciliation report separates authorized, submitted and settled refunds. A submitted refund may remain in the pending settlement bucket overnight.',
'PaymentRecord: O-906 paid by card ending 4402. Its customer updated a contact email after delivery; the original payment instrument record remains available.',
'Support handover: three pending refund inquiries require warehouse inspection. The next agent should check the photos before requesting an approval decision.' ],
'F21':[
'Authenticated recipient update for SH-66 at 10:15 UTC: 9 Cedar Lane. The carrier acknowledged the updated delivery instruction in that shipment record.',
'CarrierTracking SH-64: parcel arrived at WestHub at 07:20 UTC. A vehicle transfer is scheduled before the evening neighborhood delivery route.',
'Authenticated recipient update for SH-63 at 09:30 UTC: leave at the reception desk. The recipient included a phone number for the building receptionist.',
'RoutePlanner: Pine Road deliveries use vehicle V-12 this afternoon. The carrier grouped parcels by postal district and assigned a separate driver to Elm Street.',
'Customer service note on SH-62: the sender requested a signature on delivery. The team added the requested service option and recalculated the shipment charge.',
'AddressBook: the account profile lists 4 Elm Street as a saved address and 18 Pine Road as a secondary entry. Saved entries retain their creation dates in the account settings.',
'CarrierTracking SH-61: delivery attempt failed because the office was closed. The carrier scheduled a second attempt and sent a tracking notification to the recipient.',
'Authenticated recipient update for SH-60 at 11:00 UTC: deliver to the parcel locker. The locker access code was stored in that shipment’s delivery instruction.',
'RoutePlanner advisory: roadworks may slow vans near Cedar Lane. The dispatcher added ten minutes to the estimated arrival windows for the affected route.',
'Warehouse manifest: parcels SH-59 and SH-58 loaded into cage C-17. The operator scanned both labels and sealed the cage before transfer to the carrier.',
'Carrier service bulletin: a new collection point opened on Oak Avenue. Customer-service agents can offer it when recipients request parcel-locker delivery.',
'Shipment receipt SH-57: signed by the recipient at 15:42 UTC. The proof-of-delivery image was uploaded and linked to the tracking record.' ],
'F23':[
'CalendarService: room Birch at 15:30 has an open slot. The room supports video calls and seats six people; the facilities record shows no maintenance restriction.',
'CalendarService booking BK-41: Maple at 14:00 successfully reserved for the product review. The organizer requested a display adapter and a whiteboard.',
'RoomDirectory: Maple seats eight and includes a conference microphone. Its cleaning buffer is applied after each booking when the calendar computes available slots.',
'Assistant draft for a previous request: Birch at 16:00 is confirmed. The draft was saved in the conversation notebook during the afternoon planning session.',
'CalendarService: Cedar at 15:00 booked by the finance team under BK-43. The booking includes a remote participant link and a reminder ten minutes before start.',
'Facilities ticket FAC-22: the Oak room projector is being replaced. The room remains bookable for meetings that do not require projection.',
'CalendarService cancellation BK-37: Birch at 13:00 canceled by its organizer. The slot returned to the availability list after the cancellation was committed.',
'TeamAgenda: the planning meeting requires a room with a display. The coordinator prefers a short walking distance from the engineering floor.',
'NotificationQueue: confirmation email for BK-41 delivered to its organizer. The queue stored the delivery receipt and removed the retry entry.',
'RoomDirectory: Cedar and Maple share a supply cabinet. Facilities restocked markers and changed the door signage during the morning inspection.',
'CalendarService: Pine at 17:00 booking request failed because a conflicting reservation already exists. The requester was offered a slot at 17:30.',
'Team calendar note: the design review moved to Thursday. Its attendees received an updated invitation and the old recurring event was removed.' ],
'F24':[
'SnapshotCatalog signed lineage: snap-43 from billing-primary at 01:00. The retention job marked it as a daily recovery point and retained the associated transaction-log range.',
'IntegrityService: snap-43 integrity PASS. The verifier checked the manifest, chunk checksums and final database consistency marker before signing the result.',
'RecoveryLead authenticated approval: analytics-replica recovery to 03:00 using snap-52. The request came from the reporting team after a failed maintenance change.',
'SnapshotCatalog: snap-45 from billing-primary-test at 03:00. The test database was refreshed after its nightly integration suite completed.',
'BackupScheduler: inventory-primary incremental backup completed at 02:15. The next full snapshot is planned for the weekend maintenance window.',
'DatabaseDirectory: billing-primary serves production billing traffic. billing-primary-test is assigned to integration tests and uses a separate storage volume.',
'IntegrityService: snap-52 integrity PASS. The signed output includes the verifier build and the object-storage manifest used during validation.',
'IncidentRegistry: a read replica experienced lag during the overnight batch. The database team increased replay capacity and is monitoring the catch-up progress.',
'SnapshotRetention: snap-39 expired under the daily retention schedule. Its catalog entry remains as an audit record while the storage objects have been removed.',
'Recovery exercise log: last month’s inventory restoration completed in the isolated rehearsal cluster. The team documented startup time and row-count checks.',
'ObjectStorageStatus: archive tier retrieval for older monthly snapshots may take several hours. Recent daily snapshots remain in the standard storage tier.',
'BackupScheduler: the next billing-primary snapshot is scheduled for 04:00. The backup plan records the expected log checkpoint and the operator notification channel.' ]}
meta=json.loads((P/'data/private_variant_metadata.json').read_text())['entries'];changed=[]
for m in meta:
 if 'long_history' not in m['complexity_tags']:continue
 q=P/'data/public_cases'/f'{m["record_id"]}.json';c=json.loads(q.read_text());old=c['history'];keep=[x for x in old if not x['event_id'].startswith(('a','n'))]
 # Keep a varied subset of mundane logs, with no instruction about their relevance.
 mundane=['Facilities: visitor check-in desk opens at 08:30 on weekdays. Guests arriving earlier should use the reception intercom.','Team calendar: the monthly retrospective moved to Tuesday at 11:00. The organizer sent an updated invitation to the distribution list.','Service portal: the documentation index refreshed overnight. Search metrics show normal response times and no failed ingestion jobs.','Office logistics: a printer service visit is scheduled for Thursday. The nearby printer remains available while maintenance is underway.','Training office: two additional seats opened in next month’s incident review workshop. Registration is managed through the learning portal.','Operations dashboard: the overnight status-report job finished and its delivery receipts were recorded. The next report is scheduled for tomorrow morning.']
 noise=[dict(event_id=f'a{i+1}',role='tool',content=t) for i,t in enumerate(D[m['family_id']])]+[dict(event_id=f'n{i+1}',role='tool',content=t) for i,t in enumerate(mundane)]
 hist=[keep[0]]
 chunks=[noise[:5],noise[5:10],noise[10:15],noise[15:]]
 for i,e in enumerate(keep[1:]):hist.extend(chunks[i] if i<len(chunks) else []);hist.append(e)
 if len(keep)-1<len(chunks):
  for chunk in chunks[len(keep)-1:]:hist.extend(chunk)
 c['history']=hist
 # Existing x events sometimes contained explanatory scope annotations; factual IDs already distinguish them.
 replacements={
 'DataCouncil: winter-cohort / AcornLab / fraud-audit DENIED; this is a separate dataset and purpose.':'DataCouncil: winter-cohort / AcornLab / fraud-audit DENIED. The council requested a revised aggregation plan.',
 'CalibrationService: MX-89 certificate expired; serial MX-89 is not the requested instrument.':'CalibrationService: MX-89 certificate expired. Workshop review scheduled for Thursday.',
 'CertifiedRoster for analytics: Tess is absent. This roster covers analytics, not search.':'CertifiedRoster for analytics: Arun and Bea are certified; Tess is not listed.',
 'Shipment history SH-66: latest address 9 Cedar Lane. This is a different shipment.':'Shipment history SH-66: latest authenticated recipient address is 9 Cedar Lane.'}
 for e in hist:e['content']=replacements.get(e['content'],e['content'])
 q.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');changed.append(m['record_id'])
 m.update(serialized_characters=len(json.dumps(c,ensure_ascii=False)),history_events=len(hist),history_whitespace_words=sum(len(e['content'].split()) for e in hist))
(P/'data/private_variant_metadata.json').write_text(json.dumps(dict(entries=meta),ensure_ascii=False,indent=2)+'\n')
manifest={q.stem:hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted((P/'data/public_cases').glob('*.json'))}
(P/'data/public_author_snapshot_v2.json').write_text(json.dumps({'status':'public author snapshot after pre-prediction construct-validity review; v1 preserved','sha256':manifest,'amendment':'Replaced repetitive explicit irrelevance instructions in 10 long histories with factual operational records distinguished by task/entity/date/revision. No predictions were inspected.','changed_records':changed},indent=2)+'\n')
lengths=[dict(record_id=m['record_id'],characters=m['serialized_characters'],history_events=m['history_events'],history_words=m['history_whitespace_words'],long_history='long_history' in m['complexity_tags']) for m in meta]
stats=json.loads((P/'data/author_validation.json').read_text());stats.update(character_range=[min(x['characters'] for x in lengths),max(x['characters'] for x in lengths)],history_event_range=[min(x['history_events'] for x in lengths),max(x['history_events'] for x in lengths)],long_history_character_range=[min(x['characters'] for x in lengths if x['long_history']),max(x['characters'] for x in lengths if x['long_history'])],snapshot_version=2)
(P/'data/author_validation.json').write_text(json.dumps(stats,indent=2)+'\n');(P/'data/length_statistics.json').write_text(json.dumps(dict(summary=stats,records=lengths),indent=2)+'\n')
print(json.dumps(stats));print(changed)

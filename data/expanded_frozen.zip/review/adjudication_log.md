# Independent blind review and adjudication

96/96 action labels agree: S=37, U=46, I=13. No model prediction outputs, calls, or logs were read. The blind artifact was frozen before author gold access; this adjudication follows explicit parent authorization.

Each issue now has a stable unit_id and explicit acceptable field, policy, evidence sets plus canonical full field sets. Independent manager/finance and scan/release gates remain separate; repeated descriptions of one authorization failure were consolidated.

## Thirteen field disagreements

- `033eca0d`: Both original policy annotations concern approval of the complete total. Canonical units are separately manager and finance authorization; total/purchase are equivalent localizations for either, not two field defects.
- `170b2c9c`: Revision and public audience attach to the same missing exact-revision signed release authorization; merge duplicate facets.
- `22bf7bb9`: Urgent notice classification makes the chosen channel wrong; channel or notice localizes the same relation.
- `2e815faa`: Blind listed employee because eligibility is unresolved in omitted payload. Confirmed issue is reserved seat only; retain employee under unresolved_fields.
- `5aa9c7de`: Purpose is mismatched within recipient/dataset/purpose export authorization; accept purpose or recipient relation localization.
- `656c3d1d`: Employee ineligibility and wrong-product seat remain two independent units. Product/seat are alternatives for the second. P1 directly states same-product requirement.
- `6ffa6325`: Hold bars closure of account in permanent mode; either field localizes hold. Missing owner request is unresolved, not an additional confirmed violation.
- `79912900`: Outside-window time and invalid engineer authority are two descriptions of a single failed incident exception. Accept time or incident localization, retain both policies.
- `a6ee3444`: Attachment authorization is a recipient-attachment relation; both fields or either are accepted, not separate violations.
- `bb5e1beb`: Internal-only approval fails external recipient/purpose authorization; purpose/recipient are alternative localizations.
- `ca7e7fed`: Conflicting updates forbid choosing an address for this shipment; either endpoint localizes the relation.
- `f2281f53`: Rest restriction is an operator-shift relation, not a wrong identifier in either field.
- `fe08b13c`: No signed r8 public-release approval is one gate; revision/audience are equivalent localizations.

## Limits and freeze

- Core relations, not exhaustive requirements.
- One LLM reviewer; same-session adjudication with author expectations is not a second independent annotation.
- 24 business families are not 24 independent semantic mechanisms.
- Acceptable sets enumerate semantic equivalents established before predictions; do not tune them to model outputs.
- S/I summaries are case-specific; I denotes incomplete capture, not permission to act.

Frozen UTC: 2026-11-03T03:40:19.070893+00:00

Gold SHA256: `51fb5ee2a320009e52be643fb50151da4ec06ee1bca9eda9291448c2e2cfbec2`

All entries have annotation_status `adjudicated_llm_pretest`; original author status is preserved separately. 96/96 label agreement and 13/46 Unsupported literal field-set disagreements describe LLM annotations, not human reliability.

The original blind hash matches the parent-provided source hash. All 96 mapped evidence lists and semantic fields were checked against the preserved original. The event-map hash is `ae0c7f8fae2cd3102be135300d824ecfc8df105145870224f3c6832de3df1305`.

For 2e815faa, reporting unresolved employee eligibility as a confirmed violation is a false accusation. Only the visible reserved-seat violation belongs in issues; eligibility remains separately unresolved.

Timing clarification: “before predictions” here means before held-out test predictions. Development calls were running in parallel; the adjudicator did not inspect any development or test outputs. Gold content and its hash are unchanged.

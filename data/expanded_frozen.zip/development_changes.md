# Development-stage changes before held-out test freeze

- Before any calls, dev selection was changed from all-S first variants to S2/U3/I1 across six dev families, to exercise issue and uncertainty schemas.
- Development case 77e12e82 exposed a metric naming/logic issue: all three methods attached the missing supplier/account verification relation to both invoice and account, while the core gold field set was account. A strict equality check would penalize a valid extra field attachment. Before test predictions, the secondary metric was renamed annotated_field_set_coverage and changed to coverage of an allowed core set; false additional accusations remain assessed in the common semantic review. This does not change labels, prompts, gold, or predictions.
- Predictor prompts and aggregation semantics have not been revised using held-out predictions. No held-out prediction has been run at this change point.
